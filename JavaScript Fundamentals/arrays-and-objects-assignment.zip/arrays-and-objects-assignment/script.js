// Task 1: Create and Use an Object:
// 1) Creating an object named book with its properties
// 2) Accessing and printing properties using dot notation
// 3) Accessing and printing properties using bracket notation
// 4) Updating the isRead property to true
// 5) Adding a new property called genre with a value
// 6) Printing the updated book object

let book = {
    title: "He's Into Her",
    author: "Maxinejiji",
    pages: 4500,
    isRead: false
};

console.log(book.title); 
console.log(book.author); 
console.log(book.pages); 
console.log(book.isRead); 

console.log(book["title"]); 
console.log(book["author"]); 
console.log(book["pages"]); 
console.log(book["isRead"]); 

book.isRead = true;

book.genre = "Thriller";

console.log(book);


// Task 2: Create and Modify an Array of Objects:
// 1) Creating an array named movies containing three objects
// 2) Printing the title of the second movie in the array
// 3) Adding a new movie object to the end of the movies array
// 4) Updating the year of the first movie to 2023
// 5) Printing the entire updated array

let movies = [
    {
        title: "Man In Love",
        director: "Yin Chen-hao",
        year: 2021
    },

    {
        title: "Spider-Man: No Way Home",
        director: "Jon Watts",
        year: 2021
    },

    {
        title: "Dune: Part One",
        director: "Denis Villeneuve",
        year: 2021
    }
];

console.log(movies[1].title);

movies.push({
    title: "June Again",
    director: "JJ Winlove",
    year: 2020
});

movies[0].year = 2023;

console.log(movies);


// Task 3: Combine Objects and Arrays:
// 1) Creating an object named student containing properties
// 2) Printing the first subject in the subjects array
// 3) Adding a new subject to the subjects array
// 4) Printing the updated student object

let student = {
    name: "Charlyn",
    age: 22,
    subjects: ["Capstone 2", "Web Fundamentals", "Java Programming"]
};

console.log(student.subjects[0]);

student.subjects.push("System Integration");

console.log(student);


// Task 4: Challenge Task (Optional):
// 1) Creating an object named recipe with properties 
// 2) Adding a new ingredient to the ingredients array
// 3) Printing the name of the second ingredient in the ingredients array
// 4) Printing the entire recipe object

let recipe = {
    name: "Pork Dinuguan",
    ingredients: [
        { name: "Pork belly", quantity: "500g" },
        { name: "Pork blood", quantity: "1 cup" },
        { name: "Vinegar", quantity: "1/2 cup" },
        { name: "Garlic", quantity: "5 cloves, minced" },
        { name: "Onion", quantity: "1 medium, chopped" },
        { name: "Ginger", quantity: "1 small piece, minced" },
        { name: "Green chilies", quantity: "2 pieces, sliced" },
        { name: "Water", quantity: "1 cup" },
        { name: "Salt", quantity: "to taste" },
        { name: "Pepper", quantity: "to taste" }
    ],
    isVegetarian: false
};

recipe.ingredients.push({ name: "Bay leaves", quantity: "2 pieces" });

console.log(recipe.ingredients[1].name);

console.log(recipe);
