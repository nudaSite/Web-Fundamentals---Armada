// Task 1: Grading System:

// 1) Create a variable named score and assign a value between 0 and 100.
// 2) Write a conditional statement to assign a grade based on the score:
    // 90–100: Grade A
    // 80–89: Grade B
    // 70–79: Grade C
    // 60–69: Grade D
    // Below 60: Grade F
// 3) Log the grade to the console.

let score = 98;

if (score >= 90) {
    console.log("Grade A");
} else if (score >= 80) {
    console.log("Grade B");
} else if (score >= 70) {
    console.log("Grade C");
} else if (score >= 60) {  
    console.log("Grade D");
} else {
    console.log("Grade F");
}


// Task 2: Weather Advisor:

// 1) Create a variable named temperature and assign it a value.
// 2) Write a conditional statement to display messages based on the temperature:
    // If the temperature is below 0, log: "It's freezing outside! Bundle up!"
    // If the temperature is between 0 and 15, log: "It's cold outside. Wear a jacket."
    // If the temperature is between 16 and 30, log: "The weather is nice. Enjoy your day!"
    // If the temperature exceeds 30, log: "It's hot outside. Stay hydrated!"

let temperature = 17;

if (temperature < 0) {
    console.log("It's freezing outside! Bundle up!");
} else if (temperature <= 15) {
    console.log("It's cold outside. Wear a jacket.");
} else if (temperature <= 30) {
    console.log("The weather is nice. Enjoy your day!");
} else {
    console.log("It's hot outside. Stay hydrated!");
}
    

// Task 3: Eligibility Checker:

// 1) Create a variable named age and assign it a value.
// 2) Write a conditional statement to check the following eligibility:
    // If the age is below 13, log: "You are too young for this activity."
    // If the age is between 13 and 17, log: "You need parental permission."
    // If the age is 18 or older, log: "You are eligible for this activity."

let age = 17; 

if (age < 13) {
    console.log("You are too young for this activity.");
} else if (age <= 17) {
    console.log("You need parental permission.");
} else {
    console.log("You are eligible for this activity.");
}


// Task 4: Ticket Price Calculator:

// 1) Create variables named age and isMember.
    // age should be a number.
    // isMember should be a boolean (true or false).
// 2) Write a conditional statement to determine ticket price:
    // If the age is under 12, the ticket is free.
    // If the age is 12 or older and isMember is true, the ticket costs $10.
    // If the age is 12 or older and isMember is false, the ticket costs $15.
// Log the ticket price to the console.

let age = 13;
let isMember = false;

if (age < 12) {
    console.log("The ticket is free.");
} else if (isMember) { 
    console.log("The ticket costs $10.");
} else {
    console.log("The ticket costs $15.");
}


// Task 5: Challenge Task (Optional): Leap Year Checker:

// 11) Create a function named isLeapYear that accepts a year as an argument.
// 2) Write a conditional statement to check if the year is a leap year:
    // A year is a leap year if:
        // It is divisible by 4 and not divisible by 100.
        // Or it is divisible by 400.
// 3) Return true if the year is a leap year, otherwise, return false.
// 4) Test the function with various years and log the results.

function isLeapYear(year) {
    if ((year % 4 === 0 && year % 100 !== 0) || (year % 400 === 0)) {
        return true; 
    } else {
        return false; 
    }
}

console.log(isLeapYear(2024)); 
console.log(isLeapYear(2023)); 
console.log(isLeapYear(2002)); 
console.log(isLeapYear(1973)); 
console.log(isLeapYear(1964));

