public class LoopsPractice {
    public static void main(String[] args) {
        
        // Task 1: Multiplication Table Generator
        int number = 8; 
        System.out.println("Multiplication Table for " + number + ":");
        for (int i = 1; i <= 10; i++) {
            System.out.println(number + " x " + i + " = " + (number * i));
        }
        System.out.println(); 

        
        // Task 2: Sum of First N Natural Numbers
        int n = 7; 
        int sum = 0;
        for (int i = 1; i <= n; i++) {
            sum += i;
        }
        System.out.println("The sum of the first " + n + " numbers is: " + sum);
        System.out.println();

        
        // Task 3: Array Elements Printer
        int[] numbersArray = {3, 6, 9, 12, 15}; 
        System.out.println("Array Elements:");
        for (int i = 0; i < numbersArray.length; i++) {
            System.out.println("Array Element: " + numbersArray[i]);
        }
        System.out.println();

        
        // Task 4: Pattern Printer
        int rows = 5; 
        System.out.println("Pattern:");
        for (int i = 1; i <= rows; i++) {
            for (int j = 1; j <= i; j++) { 
                System.out.print("*");
            }
            System.out.println(); 
        }
        System.out.println();

        
        // Task 5: Reverse Array Elements
        int[] reverseArray = {10, 5, 7, 20, 2}; 
        System.out.println("Reversed Array Elements:");
        for (int i = reverseArray.length - 1; i >= 0; i--) {
            System.out.println("Reversed Element: " + reverseArray[i]);
        }
    }
}
