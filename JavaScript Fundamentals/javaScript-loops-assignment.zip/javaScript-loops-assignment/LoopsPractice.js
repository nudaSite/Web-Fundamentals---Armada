// Task 1: Multiplication Table Generator
let number = 8; 
console.log(`Multiplication Table for ${number}:`);
for (let i = 1; i <= 10; i++) {
    console.log(`${number} x ${i} = ${number * i}`);
}
console.log(); 


// Task 2: Sum of First N Natural Numbers
let n = 7; 
let sum = 0;
for (let i = 1; i <= n; i++) {
    sum += i;
}
console.log(`The sum of the first ${n} numbers is: ${sum}`);
console.log();


// Task 3: Array Elements Printer
let numbersArray = [3, 6, 9, 12, 15]; 
console.log("Array Elements:");
for (let i = 0; i < numbersArray.length; i++) {
    console.log(`Array Element: ${numbersArray[i]}`);
}
console.log();


// Task 4: Pattern Printer
let rows = 5; 
console.log("Pattern:");
for (let i = 1; i <= rows; i++) {
    console.log("*".repeat(i));
}
console.log();


// Task 5: Reverse Array Elements
let reverseArray = [10, 5, 7, 20, 2]; 
console.log("Reversed Array Elements:");
for (let i = reverseArray.length - 1; i >= 0; i--) {
    console.log(`Reversed Element: ${reverseArray[i]}`);
}
